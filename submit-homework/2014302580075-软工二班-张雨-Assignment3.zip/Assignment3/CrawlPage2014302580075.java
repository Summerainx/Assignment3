package �߳�����;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

public class CrawlPage2014302580075 {
	private String url;
	private ProfessorInfo2014302580075 professorInfo=new ProfessorInfo2014302580075();
	public CrawlPage2014302580075(String url) {
		this.url=url;
	}
	public ProfessorInfo2014302580075 getProfessorInfo() {
		try {
			this.crawler(url);
		} catch (IOException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		return professorInfo;
	}
	public void crawler(String url) throws IOException {
		/*
		 * ��ʦ������ϢҪ���������������䣨�绰�����о����򣬼��ȡ�Ҫ��д�����߳���ȡ����߳���ȡ��
		 * �ֲ�ͬ����ȡ��ʽ��ʾ������ Main.java ���С�����¼������ȡ��ʽ���Ե�����ʱ�䡣
		 */
		String mail="\\w{3,}@\\w+(\\.\\w{2,}){1,}";//�����ʼ�����
		String telephoneNumber="\\+1-\\d+-\\d+-\\d+";//����������\\d{3}-\\d+
		Pattern pmail=Pattern.compile(mail);
		Pattern pphonenum=Pattern.compile(telephoneNumber);
		
		Document document=Jsoup.connect(url).get();
		
		Element name=document.select("h2").first();
		if (name==null) {
			professorInfo.setName("NULL");
			System.out.println("NULL");
		} else {
			professorInfo.setName(name.text());
			System.out.println(name.text());
		}
		
		
		
		Element searchInterests=document.select("div.col ul").first();
		if (searchInterests==null) {
			professorInfo.setResearchInterests("NULL");
			System.out.println("NULL");
		} else {
			professorInfo.setResearchInterests(searchInterests.text());
			System.out.println("�о�����"+searchInterests.text());
		}
		
		
		
		Element simpleIntroduction=document.select("ul.titles").first();
		if (simpleIntroduction==null) {
			professorInfo.setIntroduction("NULL");
			System.out.println("NULL");
		} else {
			professorInfo.setIntroduction(simpleIntroduction.text());
			System.out.println("��飺"+simpleIntroduction.text());
		}
		
		
		
		Element publications=document.select("div#modFacultyPubs ul").first();
		if (publications==null) {
			professorInfo.setPublications("NULL");
			System.out.println("NULL");
		}
		else {
			professorInfo.setPublications(publications.text());
			System.out.println("�����"+publications.text());
		}
		
		
		
		Element education=document.select("div#twocol ul:eq(2)").first();
		if (education==null) {
			professorInfo.setEducation("NULL");
			System.out.println("NULL");
		} else {
			professorInfo.setEducation(education.text());
			System.out.println("����������"+education.text());
		}
		
		
		String pString="";
		Element phone=document.select("div#contactinfo").first().getElementsMatchingOwnText(pphonenum).first();
		Matcher phoneMatcher=pphonenum.matcher(phone.text());
		while (phoneMatcher.find()) {
			if (phoneMatcher.group()==null) {
				
				System.out.println("NULL");
			} else {
				pString=pString+phoneMatcher.group();
				System.out.println(phoneMatcher.group());
			}
		}
		if (pString=="") {
			professorInfo.setPhoneNumber("NULL");
		} else {
			professorInfo.setPhoneNumber(pString);
		}
	
		Element email=document.select("div#contactinfo").first().getElementsMatchingOwnText(pmail).first();//
		if (email==null) {
			professorInfo.setEmail("NULL");
			System.out.println("NULL");
		} else {
			professorInfo.setEmail(email.text());
			System.out.println(email.text());
		}
		
	}

}
