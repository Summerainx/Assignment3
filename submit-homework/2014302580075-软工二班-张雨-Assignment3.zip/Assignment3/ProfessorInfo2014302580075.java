package �߳�����;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class ProfessorInfo2014302580075 {
	/*
	 * ���ݿ��˳��ID,Name,PhoneNumber,Email,Education,Introduction,ResearchInterests,Publications
	 * 
	 */
	private static int ID=0;
	private String Name="";
	private String PhoneNumber="";
	private String Email="";
	private String Education="";
	private String Introduction="";
	private String ResearchInterests="";
	private String Publications="";
	private static boolean flag=false;
	private Lock lock=new ReentrantLock();
	Condition store=lock.newCondition();
	Condition write=lock.newCondition();
	
	public void setInfo(ProfessorInfo2014302580075 professorInfo) {//String Name,String PhoneNumber,String Email,String Education,
			     		//String Introduction,String ResearchInterests,String Publications
		try {
			lock.lock();
			
			while (ProfessorInfo2014302580075.flag) {
				try {
					store.await();

				} catch (InterruptedException e) {
					// TODO �Զ����ɵ� catch ��
					e.printStackTrace();
				}
			}
			this.Name=professorInfo.Name;
			this.PhoneNumber=professorInfo.PhoneNumber;
			this.Email=professorInfo.Email;
			this.Education=professorInfo.Education;
			this.Introduction=professorInfo.Introduction;
			this.ResearchInterests=professorInfo.ResearchInterests;
			this.Publications=professorInfo.Publications;
			ProfessorInfo2014302580075.flag=true;
			write.signalAll();
		} finally {
			lock.unlock();
		}
		
		
	}
	
	
	public void writeIntoDatabase(ProfessorInfo2014302580075 professorInfo) throws Exception {
		
		try {
			lock.lock();
			while (!ProfessorInfo2014302580075.flag) {
				write.await();
			}
			Class.forName("com.mysql.jdbc.Driver");
			String user="root";
			String password="3911";
			Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/Test", user, password);
			Statement statement=connection.createStatement();
			
			statement.execute("insert into teacher1(ID,Name,PhoneNumber,Email,Education,"
					+ "Introduction,ResearchInterests,Publications)values('"
					+ (++ID)+"','"
					+ professorInfo.Name+"','"
					+ professorInfo.PhoneNumber+"','"
					+ professorInfo.Email+"','"
					+ professorInfo.Education+"','"
					+ professorInfo.Introduction+"','"
					+ professorInfo.ResearchInterests+"','"+professorInfo.Publications+"')");
			
			statement.close();
			connection.close();
			System.out.println(professorInfo.getName()+"......д��ɹ�........");
			ProfessorInfo2014302580075.flag=false;
			store.signalAll();
		} finally {
			lock.unlock();
		}
		
		
		
	}
	public static int getID() {
		return ID;
	}

	public static void setID(int iD) {
		ID = iD;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getPhoneNumber() {
		return PhoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		PhoneNumber = phoneNumber;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public String getEducation() {
		return Education;
	}

	public void setEducation(String education) {
		Education = education;
	}

	public String getIntroduction() {
		return Introduction;
	}

	public void setIntroduction(String introduction) {
		Introduction = introduction;
	}

	public String getResearchInterests() {
		return ResearchInterests;
	}

	public void setResearchInterests(String researchInterests) {
		ResearchInterests = researchInterests;
	}

	public String getPublications() {
		return Publications;
	}

	public void setPublications(String publications) {
		Publications = publications;
	}

	
}
