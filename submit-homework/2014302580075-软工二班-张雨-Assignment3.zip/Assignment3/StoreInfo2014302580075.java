package �߳�����;

import java.io.IOException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class StoreInfo2014302580075 implements Runnable{
	
	private ProfessorInfo2014302580075 professorInfo=new ProfessorInfo2014302580075();
	private static String url="http://www.wpi.edu/academics/cs/research-interests.html";
	private static Elements links=new Elements();
	public StoreInfo2014302580075(ProfessorInfo2014302580075 professorInfo) {
		this.professorInfo=professorInfo;
		try {
			links=Jsoup.connect(url).get().select("a[href*=http://www.wpi.edu/academics/facultydir/]");
		} catch (IOException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		
	}
	
	@Override
	public void run() {
		int count=0;
		int number =0;
		for (Element link : links) {
			
			if (number>17&&number<25) {
				System.out.println("........."+(++count));
				CrawlPage2014302580075 crawlPage=new CrawlPage2014302580075(link.attr("href"));
				professorInfo.setInfo(crawlPage.getProfessorInfo());
				
			}	
			number++;
		}
	}
	
	
	
	
}
