package �߳�����;

import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import org.jsoup.nodes.Element;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;

public class Main2014302580075{
	
	/*
	 * �����̣߳�
	 * 1.��ȡ��ҳ������buffer��
	 * 
	 * 2.��ȡbuffer��д�����ݿ�
	 * 
	 * 3.��
	 * 
	 */
	
	 /*
	 * ���ݿ��˳��ID,Name,PhoneNumber,Email,Education,Introduction,ResearchInterests,Publications
	 */
	private static String url="http://www.wpi.edu/academics/cs/research-interests.html";
	private static ArrayList<String> Name =new ArrayList<>();
	private static ArrayList<String> PhoneNumber =new ArrayList<>();
	private static ArrayList<String> Email =new ArrayList<>();
	private static ArrayList<String> Education =new ArrayList<>();
	private static ArrayList<String> Introduction =new ArrayList<>();
	private static ArrayList<String> ResearchInterests =new ArrayList<>();
	private static ArrayList<String> Publications =new ArrayList<>();
	private static int counter=0;
	private static Elements links=new Elements();
		
	public static void main(String[] args) throws Exception {
		// TODO �Զ����ɵķ������
		/**
		 * ��ʦ������ϢҪ���������������䣨�绰�����о����򣬼��ȡ�Ҫ��д�����߳���ȡ����߳���ȡ��
		 * �ֲ�ͬ����ȡ��ʽ��ʾ������ Main.java ���С�����¼������ȡ��ʽ���Ե�����ʱ�䡣
		 *http://www.wpi.edu/academics/cs/research-interests.html
		 */
		long starttime=System.currentTimeMillis();
		links=Jsoup.connect(url).get().select("a[href*=http://www.wpi.edu/academics/facultydir/]");
		Main2014302580075 demo=new Main2014302580075();
		demo.singleThread();
		demo.multiThread();
		long endtime=System.currentTimeMillis();
		System.out.println("��ʱ��:"+(endtime-starttime));
	}
	
	public void crawler(String url) throws IOException {
		/*
		 * ��ʦ������ϢҪ���������������䣨�绰�����о����򣬼��ȡ�Ҫ��д�����߳���ȡ����߳���ȡ��
		 * �ֲ�ͬ����ȡ��ʽ��ʾ������ Main.java ���С�����¼������ȡ��ʽ���Ե�����ʱ�䡣
		 */
		String mail="\\w{3,}@\\w+(\\.\\w{2,}){1,}";//�����ʼ�����
		String telephoneNumber="\\+1-\\d+-\\d+-\\d+";//����������\\d{3}-\\d+
		Pattern pmail=Pattern.compile(mail);
		Pattern pphonenum=Pattern.compile(telephoneNumber);
		
		Document document=Jsoup.connect(url).get();
		
		Element name=document.select("h2").first();
		if (name==null) {
			Name.add("NULL");
			System.out.println("NULL");
		} else {
			Name.add(name.text());
			System.out.println(name.text());
		}
		
		
		
		Element searchInterests=document.select("div.col ul").first();
		if (searchInterests==null) {
			ResearchInterests.add("NULL");
			System.out.println("NULL");
		} else {
			ResearchInterests.add(searchInterests.text());
			System.out.println("�о�����"+searchInterests.text());
		}
		
		
		
		Element simpleIntroduction=document.select("ul.titles").first();
		if (simpleIntroduction==null) {
			Introduction.add("NULL");
			System.out.println("NULL");
		} else {
			Introduction.add(simpleIntroduction.text());
			System.out.println("��飺"+simpleIntroduction.text());
		}
		
		
		
		Element publications=document.select("div#modFacultyPubs ul").first();
		if (publications==null) {
			Publications.add("NULL");
			System.out.println("NULL");
		}
		else {
			Publications.add(publications.text());
			System.out.println("�����"+publications.text());
		}
		
		
		
		Element education=document.select("div#twocol ul:eq(2)").first();
		if (education==null) {
			Education.add("NULL");
			System.out.println("NULL");
		} else {
			Education.add(education.text());
			System.out.println("����������"+education.text());
		}
		
		
		String pString="";
		Element phone=document.select("div#contactinfo").first().getElementsMatchingOwnText(pphonenum).first();
		Matcher phoneMatcher=pphonenum.matcher(phone.text());
		while (phoneMatcher.find()) {
			if (phoneMatcher.group()==null) {
				
				System.out.println("NULL");
			} else {
				pString=pString+phoneMatcher.group();
				System.out.println(phoneMatcher.group());
			}
		}
		if (pString=="") {
			PhoneNumber.add("NULL");//
		} else {
			PhoneNumber.add(pString);//
		}
	
		Element email=document.select("div#contactinfo").first().getElementsMatchingOwnText(pmail).first();//
		if (email==null) {
			Email.add("NULL");
			System.out.println("NULL");
		} else {
			Email.add(email.text());
			System.out.println(email.text());
		}
		
	}
	
	public void singleThread() throws IOException, Exception {
		long starttime=System.currentTimeMillis();
		Class.forName("com.mysql.jdbc.Driver");
		String user="root";
		String password="3911";
		Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/Test", user, password);
		Statement statement=connection.createStatement();
	
		int number=0;
		
		for (Element link : links) {
			if (number>17&&number<25) {
				System.out.println(++counter+"���߳�"+"-----"+link.attr("href")+"\n");//
				crawler(link.attr("href"));
			}
			number++;
		}
		for (int i = 0; i < counter; i++) {
		System.out.println("('"
				+ (i+1)+"','"
				+ Name.get(i)+"','"
				+ PhoneNumber.get(i)+"','"
				+ Email.get(i)+"','"
				+ Education.get(i)+"','"
				+ Introduction.get(i)+"','"
				+ ResearchInterests.get(i)+"','"+Publications.get(i)+"')");
		
		
		statement.execute("insert into teacher1(ID,Name,PhoneNumber,Email,Education,"
				+ "Introduction,ResearchInterests,Publications)values('"
				+ (i+1)+"','"
				+ Name.get(i)+"','"
				+ PhoneNumber.get(i)+"','"
				+ Email.get(i)+"','"
				+ Education.get(i)+"','"
				+ Introduction.get(i)+"','"
				+ ResearchInterests.get(i)+"','"+Publications.get(i)+"')");
		
		}
	
		statement.close();
		connection.close();
		long endtime=System.currentTimeMillis();
		System.out.println("���߳�ʱ��:"+(endtime-starttime));
		
		
	}
	
	public void multiThread() throws Exception {
		long starttime=System.currentTimeMillis();
		ProfessorInfo2014302580075 professorInfo=new ProfessorInfo2014302580075();
		StoreInfo2014302580075 storeInfo=new StoreInfo2014302580075(professorInfo);
		WriteInfo2014302580075 writeInfo=new WriteInfo2014302580075(professorInfo);
		Thread sThread=new Thread(storeInfo);
		Thread wThread=new Thread(writeInfo);
		sThread.start();
		wThread.start();
		sThread.join();
		wThread.join();
		long endtime=System.currentTimeMillis();
		System.out.println("���߳�ʱ��:"+(endtime-starttime)+"����");
	}


}
