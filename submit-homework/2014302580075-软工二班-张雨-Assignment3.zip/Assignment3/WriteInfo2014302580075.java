package �߳�����;

import java.io.IOException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class WriteInfo2014302580075 implements Runnable{
	private static Elements links=new Elements();
	private static String url="http://www.wpi.edu/academics/cs/research-interests.html";
	private ProfessorInfo2014302580075 professorInfo=new ProfessorInfo2014302580075();
	public WriteInfo2014302580075(ProfessorInfo2014302580075 professorInfo) {
		// TODO �Զ����ɵĹ��캯�����
		this.professorInfo=professorInfo;
		try {
			links=Jsoup.connect(url).get().select("a[href*=http://www.wpi.edu/academics/facultydir/]");
		} catch (IOException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
	}

	@Override
	public void run() {
		// TODO �Զ����ɵķ������
		int number =0;
		for (Element link : links) {
			
			if (number>17&&number<25) {
				try {
					professorInfo.writeIntoDatabase(professorInfo);
				} catch (Exception e) {
					// TODO �Զ����ɵ� catch ��
					e.printStackTrace();
				}
		
			}	
			number++;
		}
		
	}
	
	
	
}
